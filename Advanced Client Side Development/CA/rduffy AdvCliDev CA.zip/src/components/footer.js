// Simple footer for the bottom of each page.

function Footer() {
    return (
        <div>
            <hr/>
            <p>Web Design by Richard Duffy © 2022</p>
        </div>
    )
}

export default Footer;