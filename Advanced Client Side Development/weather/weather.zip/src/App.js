import './App.css';
import Weather from './components/weather';

function App() {
  return (
    <div>
      <Weather />
    </div>
  );
}

export default App;