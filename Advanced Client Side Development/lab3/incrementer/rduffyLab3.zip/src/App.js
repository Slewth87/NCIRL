import logo from './logo.svg';
import './App.css';
import Incrementer from './components/incrementer';

function App() {
  return (
    <div>
      <Incrementer/>
    </div>
  );
}

export default App;
